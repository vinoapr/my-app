1. Update the following parameters in ClusterBuild.yaml 

    * ClusterName - Name of the cluster 
    * ClusterRole  - Name of AWS IAM cluster role 
    * FargateRole  - Name of AWS IAM fargate profile role 
    * Version - Kubernetes version 
    * VPCID - VPC for the AWS account 
    * PrivateSubnet - Subnet ID's in VPC 

2. Create the cluster 
    * Update the stackname below 

    `aws cloudformation create-stack --stack-name eks-1password-cluster --template-body file://ClusterBuild.yaml --capabilities CAPABILITY_NAMED_IAM`

3. Create namespace for fargate profile. This should be the same namespace for the fargate profile. 

    `kubectl create namespace dev`
    `kubectl create namespace prod` 

4. Create fargate profiles required for the deployment. 

    `eksctl create fargateprofile --cluster 1password --name coredns --namespace kube-system --labels eks.amazonaws.com/component=coredns,k8s-app=kube-dns`
    `eksctl create fargateprofile --cluster 1password --name ingresscontroller --namespace kube-system --labels app.kubernetes.io/name=alb-ingress-controller`
    `eksctl create fargateprofile --cluster 1password --name bridge --namespace dev --labels app=op-scim-bridge`
    `eksctl create fargateprofile --cluster 1password --name redis --namespace dev --labels app=op-scim-redis`

5. Configure Core DNS 

    * [comment]: # (Use the following kubectl command to remove the eks.amazonaws.com/compute-type : ec2 annotation from the CoreDNS pods.)

    `kubectl patch deployment coredns -n kube-system --type json -p='[{"op": "remove", "path": "/spec/template/metadata/annotations/eks.amazonaws.com~1compute-type"}]'`

    `kubectl rollout restart -n kube-system deployment coredns`

6. Installing AWS Load Balancer Controller(via helm), Pre-requisite - helm
    Create an IAM policy and a service account for AWS load-balancer controller version 2

    a. Download the policy

        `curl -O https://raw.githubusercontent.com/kubernetes-sigs/aws-load-balancer-controller/v2.4.4/docs/install/iam_policy.json`

    b. Create the policy in AWS 

        aws iam create-policy \
        --policy-name AWSLoadBalancerControllerIAMPolicyv2 \
        --policy-document file://iam_policy.json

    c. Create the service account
    
        eksctl create iamserviceaccount \
        --cluster=1password \
        --namespace=kube-system \
        --name=aws-load-balancer-controller \
        --role-name AmazonEKSLoadBalancerControllerRole \
        --attach-policy-arn= arn:aws:iam::702638424650:policy/AWSLoadBalancerControllerIAMPolicyv2 \
        --approve

    d. `helm repo add eks https://aws.github.io/eks-charts`

    e. `helm repo update`

    f. 
    
        helm install aws-load-balancer-controller eks/aws-load-balancer-controller \
        -n kube-system \
        --set clusterName=1password \
        --set serviceAccount.create=false \
        --set serviceAccount.name=aws-load-balancer-controller \
        --set image.repository=602401143452.dkr.ecr.us-east-1.amazonaws.com/amazon/aws-load-balancer- controller \
        --set region=us-east-1 \
        --set vpcId=vpc-0c2edf4121f98e41e

    g. In order to run AWS load balancer fargate pod, auto-discovery tags need to be added over fargate-profiles

        eksctl delete fargateprofile --cluster 1password --name ingresscontroller --namespace kube-system
        eksctl create fargateprofile --cluster 1password --name ingresscontroller --namespace kube-system -- labels app.kubernetes.io/name=aws-load-balancer-controller

7. Setup oidc-provider for the ingress controller

    `eksctl utils associate-iam-oidc-provider --cluster 1password --approve`