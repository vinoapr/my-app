kubectl create secret -n dev generic scimsession --from-file=.\scimsession 
kubectl delete secret scimsession -n op-scim-bridge

